### Reduccion de dimensiones: metodos de ordenacion

# Analisis de componentes principales
library(FactoMineR)
library(factoextra)
Celtis <- read.table("C:/R datos/Celtis.txt", header = TRUE)

# calculamos la matriz de correlación de pearson entre variables
round(cor(Celtis), 3)

# PCA
pca <- PCA(Celtis, scale.unit = TRUE)

# obtener los eigenvalues (variacion explicada)
round(pca$eig,2)

# obtener los loadings (coef. correlacion entre una variable y su respectivo PC)
round(pca$var$coord,3)

# grafico de sedimentación (scree plot)
fviz_eig(pca, geom = "bar", barfill = "gray70", barcolor = "black")

# analizar la calidad de la representacion de las variables
round(pca$var$cos2, 3)

# analizar la contribucion de las variables a los componentes
round(pca$var$contrib, 3)

# graficar el circulo de correlacion
fviz_pca_var(pca, col.var = "black")

# graficar biplot
fviz_pca_biplot(pca, col.ind = "gray70", col.var = "black")

# para obtener los valores de calidad de representacion
pca$ind$cos2

# para obtener los valores de la contribucion de las UE
pca$ind$contrib

# Si queremos extraer los scores de las UE
scores <- pca$ind$coord[, 1:3]
scores[1:10, ]

# Grafico en 3D
library(plot3D)
x <- scores[, 1]
y <- scores[, 2]
z <- scores[, 3]
points3D(x , y, z, pch = 19, cex = 1, alpha = 0.2, bty = "g", 
         colkey = FALSE, theta = -60, phi = 20, col = "darkorange", 
         xlab = "PC 1", ylab = "PC 2", zlab = "PC 3", ticktype = "detailed")

# extraemos los loadings para agregar las variables al espacio de ordenacion
loadings <- pca$var$coord[, 1:3]

# agregamos las etiquetas de las variables
text3D(x = 4*loadings[, 1] + 0.4, y = 4*loadings[, 2] + 0.4, z = 4*loadings[, 3] + 0.4, 
       labels = rownames(loadings), col = "blue", cex = 0.8, add = TRUE)

# graficamos los vectores
arrows3D(x0 = rep(0, nrow(loadings)), y0 = rep(0, nrow(loadings)), z0 = 
           rep(0, nrow(loadings)), x1 = 4*loadings[, 1], y1 = 4*loadings[,2], z1 = 
           4*loadings[, 3], col = "blue", lwd = 1, add = TRUE)

###########################################################################################

#Analisis de correspondencias
library(FactoMineR)
library(factoextra)
Aves <- read.table("C:/R datos/Aves.txt", header = TRUE)

# Crear una matriz que contenga solo los datos de los conteos
comm <- Aves[, -c(1:3)]

# Etiquetamos las filas para que contengan el sitio y la estacion del año
rownames(comm) <- paste(Aves$sitio, Aves$estacion, sep = ".")

# CA (no graficaremos la ordenacion)
ca <- CA(comm, graph = FALSE)

# obtener los eigenvalues
round(get_eigenvalue(ca), 3)

# la suma de todos los eigenvalues es igual a la inercia total
inercia <- sum(get_eigenvalue(ca)[, 1])
inercia

# calculo de la V de Cramér
V <- 100*inercia/min(dim(comm) - 1)
V

# prueba de chi-cuadrado (significancia)
chi <- inercia*sum(comm)
gl <- (nrow(comm) - 1)*(ncol(comm) - 1)
pchisq(chi, df = gl, lower.tail = FALSE)

# grafico de sedimentacion (scree plot)
fviz_screeplot(ca, barcolor = "black", barfill = "gray70")

# obtener las coordenadas (scores) de los sitios (filas)
head(ca$row$coord)

# obtener la calidad de la representacion (cos^2) de los sitios (filas)
head(ca$row$cos2)

# obtener la contribucion de los sitios (filas)
head(ca$row$contrib)

# obtener las coordenadas (scores) de las variables (columnas)
head(ca$col$coord)

# obtener la calidad de la representacion (cos^2) de las variables (columnas)
head(ca$col$cos2)

# # obtener la contribucion de las variables (columnas)
head(ca$col$contrib)

# grafico biplot con las UE y las variables (simetrico)
fviz_ca_biplot(ca, map = "symbiplot", col.row = "black", col.col = "black", repel = TRUE)

# grafico biplot perfil fila (de las especies en el espacio de las UE)
fviz_ca_biplot(ca, map = "rowprincipal", col.row = "black", col.col = "black", repel = TRUE,
               arrow = c(TRUE, TRUE))

# grafico biplot perfil columna (de las UE en el espacio de las especies)
fviz_ca_biplot(ca, map = "colprincipal", col.row = "black", col.col = "black", repel = TRUE,
               arrow = c(TRUE, TRUE))

# Variables suplementarias (factores adicionales)
fviz_ca_row(ca, col.row = "black", geom.row = "point", pointsize = 3, 
            shape.row = Aves$estacion)

fviz_ca_row(ca, col.row = "black", geom.row = "point", pointsize = 3,
            shape.row = Aves$ambiente)

###########################################################################################

# Analisis de coordenadas principales
library(FD)
library(ape)
Bulnesia <- read.table("C:/R datos/Bulnesia.txt", header = TRUE)

rownames(Bulnesia) <- Bulnesia$species

# distancia de Gower
D <- gowdis(Bulnesia)

# PCoA
pcoa <- pcoa(D)

# obtener los eigenvalores
pcoa$values

# obtener las coordenadas principales
pcoa$vectors

# grafico biplot de especies y variables
biplot(x = pcoa, Y = log(Bulnesia[, -1] + 1), plot.axes = c(1, 2))

# obtener los loadings a posteriori
loadings <- cor(Bulnesia[, -1], pcoa$vectors, method = "pearson",
                use = "complete.obs")

################################################################################

# Escalado multidimensional no métrico
library(vegan)
Aves <- read.table("C:/R datos/Aves.txt", header = TRUE)

comm <- Aves[, -c(1:3)]

# etiquetamos filas de la MBD para identificar sitio y estacion del año
rownames(comm) <- paste(Aves$sitio, Aves$estacion, sep = ".")

# NMDS
nmds <- metaMDS(comm, distance = "bray", k = 2)

# obtenemos el valor de estres
nmds$stress

# diagrama de shepard
stressplot(nmds, pch=19, p.col = "gray70", l.col = "black")

# graficamos los sitios junto con las especies 
ordiplot(nmds, type = "n")
orditorp(nmds, display = "species", air = 0.01)
orditorp(nmds, display = "sites", col = "gray50", air = 0.01)
abline(h = 0, lty = 2)
abline(v = 0, lty = 2)

# acceder a los scores de sitios y especies
scores(nmds, display = "sites")
scores(nmds, display = "species")

# explorar si se forman grupos de UE según variables que no intervienen en el analisis

# estacion
ordiplot(nmds, type = "n")
orditorp(nmds, display = "species", air = 0.01)
orditorp(nmds, display = "sites", col = "gray50", air = 0.01)
abline(h = 0, lty = 2)
abline(v = 0, lty = 2)
ordihull(nmds, groups = Aves$estacion, draw = "polygon", label = TRUE)

#ambiente
ordiplot(nmds, type = "n")
orditorp(nmds, display = "species", air = 0.01)
orditorp(nmds, display = "sites", col = "gray50", air = 0.01)
abline(h = 0, lty = 2)
abline(v = 0, lty = 2)
ordiellipse(nmds, groups = Aves$ambiente, label = TRUE)
