### Visualizando similitudes entre unidades de estudio. Analisis de agrupamientos

### Agrupamiento jerarquico (modo Q)

# Estandarizacion de la MBD
Bulnesia <- read.table("C:/R datos/Bulnesia.txt", header = TRUE)

rownames(Bulnesia) <- Bulnesia$species

z <- scale(Bulnesia[, -1])

# Calculo de la matriz de similitud (distancia taxonomica)
N <- ncol(z)

S <- dist(z, method = "euclidean")/sqrt(N)

# Seleccion del metodo de agrupamiento 
clusterS <- hclust(S, method = "single")

clusterC <- hclust(S, method = "complete")

clusterA <- hclust(S, method = "average")

clusterW <- hclust(S, method = "ward.D2")

# Construccion del dendrograma
plot(clusterA, hang = -1, main = "")

# Medida de la distorsion (matriz cofenetica)
mat.cof <- cophenetic(clusterA)

# correlacion de pearson entre la matriz cofenetica y la original
cor(mat.cof, S, method = "pearson")

# Estimacion del numero optimo de grupos
library(factoextra)

# grafico numero de grupos vs variacion intra-grupo
fviz_nbclust(z, FUN = hcut, diss = S, method = "wss", k.max = 7, linecolor = "black") + 
  xlab("Número de grupos") + ylab("Variación intra-grupo")

# visualizar los grupos sobre el dendrograma
fviz_dend(clusterA, k = 3, k_colors = c("gray40", "black", "gray70"), 
          rect = TRUE, rect_fill = TRUE, color_labels_by_k = FALSE, horiz = TRUE)

###################################################################################

### Agrupamiento jerarquico (modo R)

# trasponer la matriz (se intercambian filas por columnas)
tz <- t(z)

# calculo de la matriz de similitud
N <- ncol(tz)

tS <- dist(tz, method = "euclidean")/sqrt(N)

# metodo de agrupamiento
clusterA <- hclust(tS, method = "average")

# construir el dendrograma
plot(clusterA, hang = -1, main = "")

############################################################################

### K-medias

# Eliminar columnas con datos faltantes
z2 <- z[, -c(13, 35)]

# aplicar la funcion (3 grupos)
kmedias <- kmeans(z2, centers = 3, nstart = 1000)

# visualizar salida
kmedias

# identificar a que grupo fue asignada cada especie
kmedias$cluster

# Numero optimo de grupos
fviz_nbclust(z2, FUNcluster = kmeans, method = "wss", k.max = 7, linecolor = "black") +
  xlab("Número de grupos") + ylab("Variación intra-grupo")

# Visualizar el resultado
fviz_cluster(kmedias, data = z2, star.plot = TRUE, repel = TRUE,
             palette = c("black", "black", "black"),
             ggtheme = theme_minimal())
