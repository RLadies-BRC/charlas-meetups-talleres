# "¡Manos a los datos!"
# autora: "Lina. R-Ladies Bariloche"
# "24 de junio de 2020"

## ¿Por qué usar Rprojects?
  
# Crear un proyecto en lugar de trabajar con archivos sueltos en un directorio tiene, a mi forma de verlo, varias ventajas. En primer lugar, se puede compartir, o al menos reproducir... ya me pasó que trato de repetir un script propio y no encuentro el archivo de datos, o el directorio de trabajo está mal... etc etc. En segundo lugar, desde el proyecto veo todos los archivos disponibles, puedo abrirlos, modificar tablas, etc, y todo queda disponible para cada vez que abro el proyecto. Para mí, lo principal es en cuanto al orden (bien escaso en mi computadora).
# Al crear un nuevo proyecto, es recomendable hacerlo en una carpeta nueva, con un nombre que sea descriptivo, y en la cual guardaremos todos los archivos necesarios para trabajar, desde los datos originales hasta los resultados y gráficos que creemos. O sea... dejar de bucear en la computadora en busca de... 

### Como siempre lo primero que hago es preparar la "escena".

# Primero creo el nuevo proyecto, con create a project, elijo el directorio, y el tipo de proyecto que quiero crear, en nuestro caso _new project_. 

# Cargo los paquetes a utilizar

library(tidyverse)
library(lubridate)

# Leo los datos
data<- read_tsv("datos_meetup.txt", na = "")#leo tabulated separate file

# Acá si quisiera leer un csv usaría la función *read_csv*, también hay varios argumentos opcionales, como el tipo de separador (*sep=*), el *locale* para que interprete fechas y horas, *skip* para que salte cierta cantidad de líneas antes de empezar a leer. 

spec(data)

### Empiezo a encontrar problemitas

#### Cambiar el formato de una columna

# No me reconoce el formato de fecha entonces se lo indico con parse

data$date<-parse_date_time(data$date, "dmY", tz= "America/Argentina/Buenos_Aires") 

View(data)#chequeo los cambios

### Combinar columnas de texto

names(data) #pido los nombres

### Unir columnas
# Veo que tengo "variables" que representan lo mismo, así que las quiero **combinar** en una sola columna:
  
data %>% unite("open", exposed, open_area, na.rm = TRUE, remove = FALSE) 

# Lo veo sólo como resultado, no me queda almacenado... esto es porque no lo guardé como objeto. Va de nuevo:
  
data <- data %>% unite("open", exposed, open_area, na.rm = TRUE, remove = FALSE)

# No eliminé las variables originales para poder chequear, pero pude hacerlo poniendo `remove= TRUE`. Ahora me toca **eliminar** "manualmente".

data <- select (data, -c(exposed, open_area))

# Con el signo menos antes de `c` (concatenate), le pido que "reste" esas variables. Si tuviera una sola, directamente escribiría `data <- select (data, -open_area)`

##Reestructurar variables

# Quiero reemplazar los valores de x de las columnas de obs. de posturas por el tiempo que estuvieron en cada una. Las cols son Echado hasta despegado, `if_else` indica que donde tenga "x", reemplace con los valores de post_budget, si no, ponga `NA`.
# Al principio de la planilla usé "X" (mayúsucula), y luego pasé a usar "x" (minúscula), así que le pido que reemplace ya sea que encuentre una u otra, con *|*.Si tuviera que reemplazar valores diferentes, también se puede hacer. Es importante que le pida que utilice un formato de `NA` compatible con los números reales.

data= data %>%
  mutate(across(no_visible:Despegado, ~if_else(.x == "x"|.x =="X", post_budget, NA_real_))) 

# Repito para uso de hábitat:
  
data= data %>%
  mutate(across(open:outside_bush, ~if_else(.x == "x"|.x =="X", mh_budget, NA_real_)))
View(data)

# Cambiar el nombre a la columna "post_budget", ahora será "budget".

data<- rename (data, budget = post_budget)

## Reagrupar los datos en dos columnas

# Hago mi tabla más ordenada. Uno de los requisitos de **tidyverse** es el uso de datos ordenados, esto es, cada variable en una columna, cada muestra en una fila, y cada observación en una celda. En mi caso, lo que tengo como variables de posturas, en realidad son dos variables, por un lado el factor "postura" y por otro el tiempo que el ejemplar mantuvo la misma (post_budget).

data=gather (data, key = "posture",value = "post_budget",
             no_visible, Echado, Semi_erguido, Erguido, Despegado,
             na.rm = TRUE,
             convert = FALSE,
             factor_key = TRUE
)

# Así, las posturas dejan de ser nombres de variables, pasan a ser niveles del factor "posture", y los valores de cada una, a la variable "post_budget". (chequear la ayuda de *gather* para ver los argumentos).

## Eliminar una columna

# La columna "mh_budget" es la misma que "budget", por ende no la necesito, la elimino:
   
data<- select(data, -mh_budget)

# Nuevamente armo un factor con los nombres de las columnas de microhábitat y una variable con los valores de cada una. 

data= gather (data, key = "microhabitat", value = "mh_budget",
              open, crevice_edge, inside_crevice, over_bush, under_bushes, bush_edge, outside_bush,
              na.rm = TRUE,
              convert = FALSE,
              factor_key = TRUE
)
data= select (data, -budget)

## Cambiar la ubicación de las columnas

# No me gusta que las columnas de interés me hayan quedado al final, así que las quiero **reubicar** a continuación de la info de individuos.

data<- data %>% relocate (posture:mh_budget, .after = time)
View (data) #chequeo los cambios

## Cambiar el orden de los datos

# Ahora, me gustaría ordenar mis datos por individuo (sheet), y por hora (time): 
  
data <- data %>% arrange (sheet, time)
View (data) # ¡disfruto la vista! 

### Listo el pollo, guardo mi nueva tabla! 

## Guardar un archivo con los datos ordenados

write_tsv (data, "data.txt")

#Trabajar con los datos ordenados

# Ahora empiezo a obtener los datos que me interesan, a partir de mi tabla ya organizada.

# Abro mi planilla nueva (la ordenada o **tidy**, digamos)

datos<- read_tsv ("data.txt")

# Le pido que me obtenga el tiempo total ("post_total_budget") que cada ejemplar estuvo en una postura determinada, el tiempo medio, y la desviación estandar, y que si no utilizó una postura complete con cero.

asoleo_x_indiv<- datos%>%
  complete(sheet, posture, fill = list(post_budget = 0)) %>% 
  group_by (sheet, posture, .drop = FALSE) %>% 
  summarise ( post_total_budget = sum (post_budget), 
              media = mean (post_budget), sd = sd (post_budget))

View (asoleo_x_indiv)

# Quiero guardar los datos por sparado. Si quisiera poner uno a continuación del otro, utilizaría la función `append`.

write_tsv (asoleo_x_indiv, "asoleo_x_indiv.txt")

# Repito para microhabitat

microhabitat_x_indiv <-  datos%>%
  complete(sheet, microhabitat, fill = list(mh_budget = 0)) %>% 
  group_by (sheet,microhabitat) %>% 
  summarise ( mh_total_budget = sum (mh_budget),
              media = mean (mh_budget), sd = sd (mh_budget))

View (microhabitat_x_indiv)


write_tsv (microhabitat_x_indiv, "elong_mh_xindiv.txt")

## Representar los datos en un gráfico de torta

### Gráfico asoleo

# Calculo los porcentajes

asoleo_total <- asoleo_x_indiv %>%
  group_by (posture) %>% 
  summarise ( posture_tot = sum (post_total_budget)) %>%
  arrange(desc(posture_tot)) %>%
  mutate(prop= posture_tot*100/sum(posture_tot)) %>%
  mutate(ypos = cumsum(prop)- 0.5*prop )

# Les puse mayúsculas a los niveles del factor

asoleo_total$posture=recode (asoleo_total$posture, no_visible = "No_visible", .default= levels(asoleo_total$posture))

# Ordenar los niveles del factor

asoleo_total$posture<- fct_relevel(asoleo_total$posture, "No_visible", "Echado","Semi_erguido", "Erguido", "Despegado" )

### Creo un gráfico de barras básico

elon_post = ggplot(asoleo_total, aes(x="", y=prop, fill=posture)) + geom_bar(stat="identity", width=1)

# Convertir a torta (coordenadas polares) y agregar labels

elon_post = elon_post + coord_polar ("y", start=0) + 
  geom_text(aes(label = paste0(round(prop), "%")),color = "White", size=4, position = position_stack (vjust = 0.5))

# Agregar escala de colores

elon_post = elon_post + scale_fill_manual (values= c ("#55DDE0", "#33658A", "#2F4858", "#F6AE2D", "#F26419", "#999999")) 


# Quitar labels y agregar título

elon_post = elon_post + labs(x = NULL, y = NULL, fill = NULL, title = "L. elongatus postures budget")

#Tunear

elon_post = elon_post + theme_classic() + theme(axis.line = element_blank(),
                                                axis.text = element_blank(),
                                                axis.ticks = element_blank(),
                                                plot.title = element_text(hjust = 0.5, color = "black"))


# ver

elon_post
ggsave("elon_post.pdf", width = 20, height = 20, units = "cm")

## Gráfico microhabitat

# Calculo los porcentajes

mh_total <- microhabitat_x_indiv %>%
  group_by (microhabitat) %>% 
  summarise ( mh_tot = sum (mh_total_budget)) %>%
  arrange(desc(mh_tot)) %>%
  mutate(prop= mh_tot*100/sum(mh_tot)) %>%
  mutate(ypos = cumsum(prop)- 0.5*prop )
percent_str <- paste(round(mh_total$prop), "%", sep="")

# Modificar los nombres del factor

mh_total$microhabitat<- recode_factor(mh_total$microhabitat, open= "Open", crevice_edge= "Crevice_edge", 
                                      inside_crevice = "Inside_crevice", outside_bush= "Outside_bush", 
                                      over_bush= "Over_bush",bush_edge= "Bush_edge", 
                                      under_bush= "Under_bush")


# Creo un gráfico de barras básico

elon_mh = ggplot (mh_total, aes (x="", y=prop, fill=microhabitat)) + geom_bar (stat="identity", width=1)


# Convertir a torta (coordenadas polares) y agregar labels

elon_mh = elon_mh + coord_polar(theta = "y") + 
  geom_text(aes( label = paste0(round(prop), "%")),color = "White", size=4, position = position_stack(vjust = 0.5))

# Agregar escala de colores

elon_mh = elon_mh + scale_fill_manual(values=c("#55DDE0", "#33658A", "#2F4858", "#F6AE2D", "#F26419", "#993b2a", "#999999")) 

# Quitar labels y agregar título

elon_mh = elon_mh + labs(x = NULL, y = NULL, fill = NULL, title = "L. elongatus microhabitat use")

# Tunear

elon_mh = elon_mh + theme_classic() + theme(axis.line = element_blank(),
                                            axis.text = element_blank(),
                                            axis.ticks = element_blank(),
                                            plot.title = element_text(hjust = 0.5, color = "black"))

# Ver

elon_mh
ggsave("elon_mh.pdf", width = 20, height = 20, units = "cm")


