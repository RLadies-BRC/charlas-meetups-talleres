#An�lisis bibliom�trico en R

#Descargo una b�squeda bibliogr�fica de Scopus en formato .bib y la guardo en la carpeta de trabajo 

#Paquetes:
library(bibliometrix)
library (ggplot2)
library(wordcloud2) #nube de palabras

#Cambiar el directorio de trabajo
Ctrl+Shift+H

setwd("G:/Mi unidad/Rladies/Analisis bibliometrico/R")

#Links con info sobre bibliometrix
#https://cran.r-project.org/web/packages/bibliometrix/vignettes/bibliometrix-vignette.html
#http://bibliometrix.org/documents/bibliometrix_Report.html

#Cargar la base como un archivo de bibliograf�a de bibliometrix
#Es una base de datos relacionada con la revisi�n sobre la macroecolog�a en Argentina
M <- convert2df("G:/Mi unidad/Rladies/Analisis bibliometrico/R/scopus325.bib", dbsource = "scopus", format = "bibtex")
#�Qu� contiene?
?convert2df
View(M)

#cada art�culo tiene su url 
browseURL("http://www.scopus.com/inward/record.uri?eid=2-s2.0-85069933680&doi=10.1016%2fj.cretres.2019.06.012&partnerID=40&md5=18f336ce65a45ed58360220e46c39b47")

#Hacer el an�lisis bibliom�trico
results <- biblioAnalysis(M, sep = ";")
?biblioAnalysis

View(results)

# Articles		 the total number of manuscripts
# Authors		 the authors' frequency distribution
# AuthorsFrac		 the authors' frequency distribution (fractionalized)
# FirstAuthors		 corresponding author of each manuscript
# nAUperPaper		 the number of authors per manuscript
# Appearances		 the number of author appearances
# nAuthors		 the number of authors
# AuMultiAuthoredArt		 the number of authors of multi-authored articles
# MostCitedPapers		 the list of manuscripts sorted by citations
# Years		 publication year of each manuscript
# FirstAffiliation		 the affiliation of the first author
# Affiliations		 the frequency distribution of affiliations (of all co-authors for each paper)
# Aff_frac		 the fractionalized frequency distribution of affiliations (of all co-authors for each paper)
# CO		 the affiliation country of the first author
# Countries		 the affiliation countries' frequency distribution
# CountryCollaboration		 Intra-country (SCP) and intercountry (MCP) collaboration indices
# TotalCitation		 the number of times each manuscript has been cited
# TCperYear		 the yearly average number of times each manuscript has been cited
# Sources		 the frequency distribution of sources (journals, books, etc.)
# DE		 the frequency distribution of authors' keywords
# ID		 the frequency distribution of keywords associated to the manuscript by SCOPUS and Clarivate Analytics Web of Science database


#resumen de los resultados
options(width=100)
S <- summary(object = results, k = 325, pause = FALSE)
names(S)
View(S)

S$AnnualProduction
S$MostRelKeywords

#Plots del bibliometrix
plot(x = results, k = 325, pause = FALSE)
p=plot(x = results, k = 325, pause = FALSE)
#al guardar los gr�ficos en un objeto, luego puedo acceder por separado
p$MostProdCountries
p$AnnualScientProd

#Graficar la producci�n anual
#los datos los tengo en
S$AnnualProduction
str(S$AnnualProduction)  #Veo que Year es un factor y lo tengo que pasar a variable num�rica
as.numeric(as.character(S$AnnualProduction$`Year   `))

ggplot(data=as.data.frame(S$AnnualProduction)) + geom_point(aes(x=as.numeric(as.character(S$AnnualProduction$Year)), y=Articles)) + 
  theme_classic() + labs(y="N�mero de art�culos", x = "A�os" )

#ggsave("Figure_ProdAnual.pdf", width = 10.5, height = 10, units = "cm")

#Nube de palabras con keywords
#Genero las 100 keywords m�s frecuentes
S100 <- summary(object = results, k = 100, pause = FALSE)
View(S100$MostRelKeywords)
S100$MostRelKeywords$"Author Keywords (DE)"
S100$MostRelKeywords$Articles
tx=data.frame(word=S100$MostRelKeywords$"Author Keywords (DE)", freq=as.numeric(S100$MostRelKeywords$Articles ))
tx

#Hacer el gr�fico
wordcloud2(data=tx, size=0.5)

# Si lo quiero guardar a un objeto
nube <- wordcloud2(data=tx, size=0.5)

# save it in html
library("htmlwidgets")
saveWidget(nube,"tmp3.html",selfcontained = F)

#Opt� por descargarla desde la ventana de R estudio en bmp


#Fig most productive countries mejorada

p$MostProdCountries
S$MostProdCountries #es la que quiero, tengo que seleccionar los 13 primeros 
S$MostProdCountries[1:13,] #los 13 primeros # pero en este formato no me sirve para ggplot2

str(p$MostProdCountries)

p$MostProdCountries$ data $ Country
p$MostProdCountries$ data $ Freq 
p$MostProdCountries$ data $  Collaboration

Prod=data.frame(p$MostProdCountries$ data $ Country, p$MostProdCountries$ data $ Freq, p$MostProdCountries$ data $  Collaboration)

View(Prod) #necesito las 13 primeras lineas y la linea 326, paises con frecuencia 2 o m�s

newdata <- subset(Prod, Prod$p.MostProdCountries.data.Freq>1)

View(newdata) # esto es lo que quiero graficar, me falta poner los paises en castellano y reemplazar SP por A (Argentino) y MCP por M (m�ltiples nacionalidades)
names(newdata)

ploti= ggplot(newdata, aes(x=p.MostProdCountries.data.Country, y=p.MostProdCountries.data.Freq, fill=p.MostProdCountries.data.Collaboration)) + geom_bar(stat="identity") + theme_classic() + theme(legend.position='none') + labs(y="N�mero de art�culos", x = "Pa�ses") + coord_flip() + scale_fill_grey()
ploti

#Si quiero poner los paises en castellano, hago labels
Paises= c("Argentina", "Estados Unidos", "Brasil", "Reino Unido", "Espa�a", "Alemania", "Chile", "Dinamarca", "Italia", "M�xico", "Sud�frica", "Uruguay", "Venezuela", "Argentina")
ploti + scale_x_discrete(labels=Paises)


#Fig Revistas m�s utilizadas
#Necesito un summary con 15 revistas nada m�s
S15 <- summary(object = results, k = 15, pause = FALSE)

S15$MostRelSources
Revcorta= c("J Biogeogr", "Glob Ecol Biogeogr", "PLOS ONE", "Biol Invasions", "Zootaxa",  "Austral Ecol", "J Arid Environ", "Biodivers Conserv", "Biol J Linn Soc", "Ecography", "Ecology", "Science", "Ann Entomol Soc Am", "Divers Distrib", "Environ Entomol" ) 
Revistascitadas <- data.frame(Frec=S15$MostRelSources$Articles, revista =S15$MostRelSources$Sources, Revcorta )
head(Revistascitadas)
Revistascitadas$Revcorta = factor(Revistascitadas$Revcorta, levels = Revistascitadas$Revcorta[order(Revistascitadas$Frec)])

ggplot(Revistascitadas, aes(x=Revcorta, y=Frec)) + geom_bar(stat="identity") + theme_classic() + labs(y="N�mero de art�culos", x = "") + coord_flip()


#Figura Trabajos citados
#Para ver a cuales trabajos citan
CR <- citations(M, field = "article", sep = ";")
cbind(CR$Cited[1:10])
label = (c("Rangel et al. 2010", "Hijmans et al 2005", "Borcard et al. 1992", "Gaston 2000", "Legendre 1993", "Brown y Maurer 1989",  "Pagel 1999", "Rosenzweig 1995", "Borcard y Legendre 2002", "Olson et al. 2001"))
trabajoscitados <- data.frame(Frec=cbind(CR$Cited[1:10]), cita = row.names(cbind(CR$Cited[1:10])), citacorta= label )
View(trabajoscitados)

#tengo que ordenar los factores expl�citamente para que me los ponga en orden
trabajoscitados$citacorta <- factor(trabajoscitados$citacorta, levels = trabajoscitados$citacorta[order(trabajoscitados$Frec)])

ggplot(trabajoscitados, aes(x=citacorta, y=Frec)) + geom_bar(stat="identity") + theme_classic() + labs(y="N�mero de citas", x = "Art�culo") + coord_flip()


#Para hacer la FIg del histograma de autores Argentinos, es necesario trabajar con el CSV, porque la base de bibliometrix, no guarda bien las afiliACIONES, EN EL CASO DE QUE LA AFILICACI�N DE VARIOS AUTORES ES COMPARTIDA
#No lo vamos  hacer ac�





